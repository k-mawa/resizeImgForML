Requirements
------------
* Python 3.x

Features
--------
* nothing

History
-------

* 0.0.1 (2020-10-27)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* first release

Usage
------------
please look at Github README

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Plan to upgrade
---------------------

* open image through one unipue path(it is useful for WebApp like Django) 
* open one directory and all of image at the directory 
* resize & save images for MNIST

and more, if i can

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* first release