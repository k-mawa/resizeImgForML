from .resizeImgForML import *

__copyright__    = 'Copyright (C) 2020 Kosuke Mawatari'
__version__      = '0.0.7'
__license__      = 'MIT'
__author__       = 'Kosuke Mawatari'
__url__          = 'https://github.com/k-mawa/resizeImgForML'